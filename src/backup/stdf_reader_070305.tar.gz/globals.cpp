

#include "globals.h"

#include <iostream>

ByteOrder getNativeByteOrder( void ) {
    ByteOrder endianness;
    endianness = NotDefined;
    // Check endian-ness during runtime
    unsigned int endianInt;
    endianInt = 0x04030201;
    char* pUINT = (char *) &endianInt;
    if(pUINT[0] == 0x04) { 
        endianness = BigEndian;
    }
    else if(pUINT[0] == 0x01) { 
        endianness = LittleEndian;
    }
    else if(pUINT[0] == 0x03) { 
        endianness = PDPEndian;
    }

    return endianness;
}

CN::CN(void) {
    length = 0;
    str = "";
}

CN CN::operator= (string s) {
    str = s;
    length = str.length();
    return *this;
}

/*
U2 CN::operator+ (U2 num) {
    U2 len;
    len = num + length;
    return len;
}
*/

ostream& operator<<(ostream& os, CN& cn) {
#ifdef DEBUG
    os << "[" << (int) cn.length << "] ";
#endif
    os << cn.str;
    return os;
}

DN::DN(void) {
    count = 0;
    data.clear();
}



