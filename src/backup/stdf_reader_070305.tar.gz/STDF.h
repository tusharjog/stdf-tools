
#ifndef _STDF_H_
#define _STDF_H_

#include "defines.h"
#include "globals.h"
#include <string>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

class STDFStream;

class RecordHeader {
    private:
    protected:
        U2 length;
        U1  type;
        U1  subType;
    public:
        RecordHeader(RecordType t);
        RecordHeader(U1 t = 0, U1 st = 0, U2 l = 0);
        void setLength(U2 l);
        void setType(U1 t);
        void setSubType(U1 st);
        void set(U1 t, U1 st, U2 l);

        U2     getLength(void);
        U1     getType(void);
        U1     getSubType(void);
        string getRecordType(void);
        friend ostream& operator<<(ostream& os, RecordHeader& rh);
        friend STDFStream& operator>>(STDFStream& stdf, RecordHeader& rh);
        friend STDFStream& operator<<(STDFStream& stdf, RecordHeader& rh);
};

class FARRecord {
    public:
        // Constructors
        FARRecord(U1 cpu = 2, U1 ver = 4);
        // Accessors
        U1 getCpuType(void);
        U1 getStdfVersion(void);

        // Utility
        RecordHeader getRecordHeader(void);
        U2 getLength(void) { return 2; }

        // Streaming
        friend ostream&      operator<<(ostream&      os, FARRecord& far);
        friend stringstream& operator<<(stringstream& os, FARRecord& far);
        friend STDFStream& operator>>(STDFStream& stdf, FARRecord& far);
        friend STDFStream& operator<<(STDFStream& stdf, FARRecord& far);

    private:
        // Member variables
        U1 cpuType, stdfVersion;
};

class ATRRecord {
    public:
        ATRRecord(void);
        U2 getLength(void);

        friend ostream&    operator<<(ostream&    os,   ATRRecord& atr);
        friend STDFStream& operator>>(STDFStream& stdf, ATRRecord& atr);
        friend STDFStream& operator<<(STDFStream& stdf, ATRRecord& atr);
    private:
        // Member variables
        U4 modTime;
        CN commandLine;
};

class MIRRecord {
    public:
        MIRRecord(void);
        U2 getLength(void);

        friend ostream&    operator<<(ostream&    os,   MIRRecord& mir);
        friend STDFStream& operator>>(STDFStream& stdf, MIRRecord& mir);
        friend STDFStream& operator<<(STDFStream& stdf, MIRRecord& mir);
    private:
        // Member variables
        U4 setupTime, startTime;
        U1 stationNumber;
        C1 modeCode, retestCode, protectionCode;
        U2 burninTime;
        C1 commandCode;
        CN lotID,         partType,         nodeName,      testerType;
        CN jobName,       jobRevision,      sublotID,      operatorName;
        CN executiveType, executiveVersion, testCode,      testTemp;
        CN userText,      auxFile,          packageType,   familyID;
        CN dateCode,      facilityID,       floorID,       processID;
        CN operationFreq, specName,         specVersion,   flowID;
        CN setupID,       designRev,        engineeringID, romCode;
        CN serialNumber,  supervisorName;

};

class SDRRecord {
    public:
        SDRRecord(void);
        U2 getLength(void);
        friend ostream&    operator<<(ostream&    os,   SDRRecord& sdr);
        friend STDFStream& operator>>(STDFStream& stdf, SDRRecord& sdr);
        friend STDFStream& operator<<(STDFStream& stdf, SDRRecord& sdr);
    private:
        U1 headNumber, siteGroup, siteCount;
        std::vector<U1> siteNumbers;
        CN     handlerType,     handlerID;
        CN        cardType,        cardID;
        CN        loadType,        loadID;
        CN         dibType,         dibID;
        CN       cableType,       cableID;
        CN   contactorType,   contactorID;
        CN       laserType,       laserID;
        CN       extraType,       extraID;

};

class PMRRecord {
    public:
        PMRRecord(void);
        U2 getLength(void);
        RecordHeader getRecordHeader(void);

        friend ostream&    operator<<(ostream&    os,   PMRRecord& pmr);
        friend STDFStream& operator>>(STDFStream& stdf, PMRRecord& pmr);
        friend STDFStream& operator<<(STDFStream& stdf, PMRRecord& pmr);
    private:
        U2 index;
        U2 channelType;
        CN channelName;
        CN physicalName, logicalName;
        U1 headNum, siteNum;
};

class PGRRecord {
    public:
        PGRRecord(void);
        U2 getLength(void);
        RecordHeader getRecordHeader(void);

        friend ostream&    operator<<(ostream&    os,   PGRRecord& pgr);
        friend STDFStream& operator>>(STDFStream& stdf, PGRRecord& pgr);
        friend STDFStream& operator<<(STDFStream& stdf, PGRRecord& pgr);
    private:
        U2 index;
        CN groupName;
        U2 indexCount;
        std::vector<U2> pmrIndexes;
};

class PIRRecord {
    public:
        PIRRecord(void);
        U2 getLength(void);
        
        friend ostream&    operator<<(ostream&    os,   PIRRecord& pir);
        friend STDFStream& operator>>(STDFStream& stdf, PIRRecord& pir);
        friend STDFStream& operator<<(STDFStream& stdf, PIRRecord& pir);
    private:
        U1 headNumber, siteNumber;
};

/*
class GDRRecord {
    public:
        GDRRecord(void);
    private:
        U2 fieldCount;
        VN genericData;
};
*/

class FTRRecord {
    public:
        FTRRecord(void);
        U2 getLength(void);
    private:
        U4 testNumber;
        U1 headNumber,   siteNumber;
        B1 testFlag,     optFlag;
        U4 cycleCount,   relVecAdd,  repeatCount, numFail;
        I4 xFailAdd,     yFailAdd;
        I2 vectorOffset;
        U2 rtnCount,     pgmCount;
        std::vector<U2> rtnIndexes;
        std::vector<N1> rtnStates;
        std::vector<U2> pgmIndexes;
        std::vector<N1> pgmStates;
        DN failPin;
        CN vectorName, timeSet, opCode, testText;
        CN alarmID, progText, resultText;
        //-----------------------------------------
        U1 patGNumber;
        DN spinMap;
};

#endif

