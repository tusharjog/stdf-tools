
#ifndef _GLOBALS_H_
#define _GLOBALS_H_

#include "defines.h"
#include <vector>

ByteOrder getNativeByteOrder( void );

// Maybe put this in STDF.h STDF.cpp
class CN {
    public:
        CN(void);
        char length;
        string str;
        CN operator= (string s);
//        U2 operator+(U2 num);
        friend ostream& operator<<(ostream& os, CN& cn);
};

class DN {
    public:
        DN(void);
        U2 count;
        std::vector<U1> data;
};

#endif


