
#include "STDF.h"
#include "STDFStream.h"

RecordHeader::RecordHeader(RecordType t) {
    length = 0;
    switch(t) {
        case FAR: type = 0;  subType = 10; break;
        case ATR: type = 0;  subType = 20; break;

        case MIR: type = 1;  subType = 10; break;
        case MRR: type = 1;  subType = 20; break;
        case PCR: type = 1;  subType = 30; break;
        case HBR: type = 1;  subType = 40; break;
        case SBR: type = 1;  subType = 50; break;
        case PMR: type = 1;  subType = 60; break;
        case PGR: type = 1;  subType = 62; break;
        case PLR: type = 1;  subType = 63; break;
        case RDR: type = 1;  subType = 70; break;
        case SDR: type = 1;  subType = 80; break;

        case WIR: type = 2;  subType = 10; break;
        case WRR: type = 2;  subType = 20; break;
        case WCR: type = 2;  subType = 30; break;

        case PIR: type = 5;  subType = 10; break;
        case PRR: type = 5;  subType = 20; break;

        case TSR: type = 10;  subType = 30; break;

        case PTR: type = 15; subType = 10; break;
        case MPR: type = 15; subType = 15; break;
        case FTR: type = 15; subType = 20; break;

        case BPS: type = 20; subType = 10; break;
        case EPS: type = 20; subType = 20; break;

        case GDR: type = 50; subType = 10; break;
        case DTR: type = 50; subType = 30; break;

        default:  type = 0;  subType = 0;  break;
    };
}

RecordHeader::RecordHeader(U1 t, U1 st, U2 l) {
    length  = l;
    type    = t;
    subType = st;
}

void RecordHeader::set(U1 t, U1 st, U2 l) {
    type = t;
    subType = st;
    length = l;
}

void RecordHeader::setLength(U2 l) {
    length = l;
}

void RecordHeader::setType(U1 t) {
    type = t;
}

void RecordHeader::setSubType(U1 st) {
    subType = st;
}

U2 RecordHeader::getLength(void) {
    return length;
}

U1 RecordHeader::getType(void) {
    return type;
}

U1 RecordHeader::getSubType(void) {
    return subType;
}

string RecordHeader::getRecordType(void) {
    string s;

    if(type == 0) {
        switch(subType) {
            case 10 : s = "FAR"; break;
            case 20 : s = "ATR"; break;
            default: s = "<>";
        }
    }
    else if(type == 1) {
        switch(subType) {
            case 10 : s = "MIR"; break;
            case 20 : s = "MRR"; break;
            case 30 : s = "PCR"; break;
            case 40 : s = "HBR"; break;
            case 50 : s = "SBR"; break;
            case 60 : s = "PMR"; break;
            case 62 : s = "PGR"; break;
            case 63 : s = "PLR"; break;
            case 70 : s = "RDR"; break;
            case 80 : s = "SDR"; break;
            default: s = "<>";
        }
    }
    else if(type == 2) {
        switch(subType) {
            case 10 : s = "WIR"; break;
            case 20 : s = "WRR"; break;
            case 30 : s = "WCR"; break;
            default: s = "<>";
        }
    }
    else if(type == 5) {
        switch(subType) {
            case 10 : s = "PIR"; break;
            case 20 : s = "PRR"; break;
            default: s = "<>";
        }
    }
    else if(type == 10) {
        switch(subType) {
            case 30 : s = "TSR"; break;
            default: s = "<>";
        }
    }
    else if(type == 15) {
        switch(subType) {
            case 10 : s = "PTR"; break;
            case 15 : s = "MPR"; break;
            case 20 : s = "FTR"; break;
            default: s = "<>";
        }
    }
    else if(type == 20) {
        switch(subType) {
            case 10 : s = "BPS"; break;
            case 20 : s = "EPS"; break;
            default: s = "<>";
        }
    }
    else if(type == 50) {
        switch(subType) {
            case 10 : s = "GDR"; break;
            case 30 : s = "DTR"; break;
            default: s = "<>";
        }
    }
    else if(type == 180) {
        s = "Reserved for use by Image software";
    }
    else if(type == 181) {
        s = "Reserved for use by IG900 software";
    }
    else {
        s = "<>";
    }
    return s;
}


ostream& operator<<(ostream& os, RecordHeader& rh) {
    return os << (int) rh.length << "\t" 
        << (int) rh.type << "\t" 
        << (int) rh.subType << "\t" 
        << rh.getRecordType();
}

STDFStream& operator>>(STDFStream& stdf, RecordHeader& rh) {
    stdf >> rh.length >> rh.type >> rh.subType;
    return stdf;
}
STDFStream& operator<<(STDFStream& stdf, RecordHeader& rh) {
    stdf << rh.length << rh.type << rh.subType;
    return stdf;
}

FARRecord::FARRecord(U1 cpu, U1 ver) {
    cpuType     = cpu;
    stdfVersion = ver;
}

U1 FARRecord::getCpuType(void) {
    return cpuType;
}

U1 FARRecord::getStdfVersion(void) {
    return stdfVersion;
}

RecordHeader FARRecord::getRecordHeader(void) {
    RecordHeader rec( FAR);
    rec.setLength(2);
    return rec;
}

ostream& operator<<(ostream& os, FARRecord& far) {
    return os << "\tCpu Type: " << (int) far.cpuType 
        << "\tSTDF Version: " << (int) far.stdfVersion;
}
stringstream& operator<<(stringstream& os, FARRecord& far) {
    os << "\tCpu Type: " << (int) far.cpuType << endl;
    os << "\tStdf Version: " << (int) far.stdfVersion << endl;
    return os;
}

STDFStream& operator>>(STDFStream& stdf, FARRecord& far) {
    stdf >> far.cpuType >> far.stdfVersion;
    return stdf;
}

STDFStream& operator<<(STDFStream& stdf, FARRecord& far) {
    RecordHeader rec = far.getRecordHeader();
    U1 nativeCpuType = 2;
    if(stdf.getByteOrder() == LittleEndian) {
        nativeCpuType = 2;
    }
    else if(stdf.getByteOrder() == BigEndian) {
        nativeCpuType = 1;
    }
    stdf << rec;
//    stdf << far.cpuType;
    stdf << nativeCpuType;
    stdf << far.stdfVersion;
    return stdf;
}


MIRRecord::MIRRecord(void) {
}

U2 MIRRecord::getLength(void) {
    U2 len = 0;
    len += 4 + 4 + 1 + 1 + 1 + 1 + 2 + 1;
    len += 1 + lotID.length;
    len += 1 + partType.length;
    len += 1 + nodeName.length;
    len += 1 + testerType.length;
    len += 1 + jobName.length;
    len += 1 + jobRevision.length;
    len += 1 + sublotID.length;
    len += 1 + operatorName.length;
    len += 1 + executiveType.length;
    len += 1 + executiveVersion.length;
    len += 1 + testCode.length;
    len += 1 + testTemp.length;
    len += 1 + userText.length;
    len += 1 + auxFile.length;
    len += 1 + packageType.length;
    len += 1 + familyID.length;
    len += 1 + dateCode.length;
    len += 1 + facilityID.length;
    len += 1 + floorID.length;
    len += 1 + processID.length;
    len += 1 + operationFreq.length;
    len += 1 + specName.length;
    len += 1 + specVersion.length;
    len += 1 + flowID.length;
    len += 1 + setupID.length;
    len += 1 + designRev.length;
    len += 1 + engineeringID.length;
    len += 1 + romCode.length;
    len += 1 + serialNumber.length;
    len += 1 + supervisorName.length;

    return len;
}

STDFStream& operator>>(STDFStream& stdf, MIRRecord& mir) {
    stdf >> mir.setupTime >> mir.startTime;
    stdf >> mir.stationNumber;
    stdf >> mir.modeCode >> mir.retestCode >> mir.protectionCode;
    stdf >> mir.burninTime;
    stdf >> mir.commandCode;
    stdf >> mir.lotID >> mir.partType >> mir.nodeName >> mir.testerType;
    stdf >> mir.jobName >> mir.jobRevision >> mir.sublotID >> mir.operatorName;
    stdf >> mir.executiveType >> mir.executiveVersion >> mir.testCode >> mir.testTemp;
    stdf >> mir.userText >> mir.auxFile >> mir.packageType >> mir.familyID;
    stdf >> mir.dateCode >> mir.facilityID >> mir.floorID >> mir.processID;
    stdf >> mir.operationFreq >> mir.specName >> mir.specVersion >> mir.flowID;
    stdf >> mir.setupID >> mir.designRev >> mir.engineeringID >> mir.romCode;
    stdf >> mir.serialNumber >> mir.supervisorName;
    return stdf;
}
STDFStream& operator<<(STDFStream& stdf, MIRRecord& mir) {
    RecordHeader rec(MIR);
    rec.setLength(mir.getLength());

    stdf << rec;
    stdf << mir.setupTime << mir.startTime;
    stdf << mir.stationNumber;
    stdf << mir.modeCode << mir.retestCode << mir.protectionCode;
    stdf << mir.burninTime;
    stdf << mir.commandCode;
    stdf << mir.lotID << mir.partType << mir.nodeName << mir.testerType;
    stdf << mir.jobName << mir.jobRevision << mir.sublotID << mir.operatorName;
    stdf << mir.executiveType << mir.executiveVersion << mir.testCode << mir.testTemp;
    stdf << mir.userText << mir.auxFile << mir.packageType << mir.familyID;
    stdf << mir.dateCode << mir.facilityID << mir.floorID << mir.processID;
    stdf << mir.operationFreq << mir.specName << mir.specVersion << mir.flowID;
    stdf << mir.setupID << mir.designRev << mir.engineeringID << mir.romCode;
    stdf << mir.serialNumber << mir.supervisorName;

    return stdf;
}

ostream& operator<<(ostream& os, MIRRecord& mir) {
    string sep = "\t";
    os << sep << "Setup Time: " << mir.setupTime << endl;
    os << sep << "Start Time: " << mir.startTime << endl;
    os << sep << "Station Number: " << (int) mir.stationNumber << endl;
    os << sep << "Test Mode Code: " << "\'" << mir.modeCode << "\'" << endl;
    os << sep << "Lot Retest Code: " << "\'" << mir.retestCode << "\'" << endl;
    os << sep << "Data Protection Code: " << "\'" << mir.protectionCode << "\'" << endl;
    os << sep << "Burn-in Time (in minutes): " << mir.burninTime << endl;
    os << sep << "Command Code: " << "\'" << mir.commandCode << "\'" << endl;
    os << sep << "Lot ID: " << mir.lotID << endl;
    os << sep << "Part Type: " << mir.partType << endl;
    os << sep << "Node Name: " << mir.nodeName << endl;
    os << sep << "Tester Type: " << mir.testerType << endl;
    os << sep << "Job Name: " << mir.jobName << endl;
    os << sep << "Job Revision: " << mir.jobRevision << endl;
    os << sep << "SubLot ID: " << mir.sublotID << endl;
    os << sep << "Operator Name: " << mir.operatorName << endl;
    os << sep << "Tester Executive Software Type: " << mir.executiveType << endl;
    os << sep << "Tester exec software version number: " << mir.executiveVersion << endl;
    os << sep << "Test Code: " << mir.testCode << endl;
    os << sep << "Test Temperature: " << mir.testTemp << endl;
    os << sep << "Generic User Text: " << mir.userText << endl;
    os << sep << "TODO" << endl;
    return os;
}

ATRRecord::ATRRecord(void) {
    modTime = 0;
    commandLine.str = "";
    commandLine.length = 0;
}

U2 ATRRecord::getLength(void) {
    U2 len;
    len = 4 + (1 + commandLine.length);

    return len;
}

STDFStream& operator>>(STDFStream& stdf, ATRRecord& atr) {
    stdf >> atr.modTime >> atr.commandLine;
    return stdf;
}
STDFStream& operator<<(STDFStream& stdf, ATRRecord& atr) {
    RecordHeader rec(ATR);
    rec.setLength(atr.getLength());
    stdf << rec;
    stdf << atr.modTime << atr.commandLine;
    return stdf;
}
ostream& operator<<(ostream& os, ATRRecord& atr) {
    string sep = "\t";
    os << sep << "Modification Time: " << atr.modTime << endl;
    os << sep << "Command Line: " << atr.commandLine << endl;
    return os;
}

//
//  SDR - Site Description Record
//
SDRRecord::SDRRecord(void) {
    headNumber = siteGroup = siteCount = 0;
}

U2 SDRRecord::getLength(void) {
    U2 len;

    len = 1 + 1 + 1 + 1*siteCount;
    len += 1 + handlerType.length;
    len += 1 + handlerID.length;
    len += 1 + cardType.length;
    len += 1 + cardID.length;
    len += 1 + loadType.length;
    len += 1 + loadID.length;
    len += 1 + dibType.length;
    len += 1 + dibID.length;
    len += 1 + cableType.length;
    len += 1 + cableID.length;
    len += 1 + contactorType.length;
    len += 1 + contactorID.length;
    len += 1 + laserType.length;
    len += 1 + laserID.length;
    len += 1 + extraType.length;
    len += 1 + extraID.length;

    return len;
}

STDFStream& operator>>(STDFStream& stdf, SDRRecord& sdr) {
    stdf >> sdr.headNumber >> sdr.siteGroup >> sdr.siteCount;
    for(unsigned char i = 0; i<sdr.siteCount; i++) {
        U1 num;
        stdf >> num;
        sdr.siteNumbers.push_back(num);
    }
    stdf >> sdr.handlerType   >> sdr.handlerID;
    stdf >> sdr.cardType      >> sdr.cardID;
    stdf >> sdr.loadType      >> sdr.loadID;
    stdf >> sdr.dibType       >> sdr.dibID;
    stdf >> sdr.cableType     >> sdr.cableID;
    stdf >> sdr.contactorType >> sdr.contactorID;
    stdf >> sdr.laserType     >> sdr.laserID;
    stdf >> sdr.extraType     >> sdr.extraID;
    return stdf;
}
STDFStream& operator<<(STDFStream& stdf, SDRRecord& sdr) {
    RecordHeader rec(SDR);
    rec.setLength(sdr.getLength());
    stdf << rec;
    stdf << sdr.headNumber << sdr.siteGroup << sdr.siteCount;
    if(sdr.siteCount > 0) {
        std::vector<U1>::iterator iter;
        for(iter = sdr.siteNumbers.begin(); iter != sdr.siteNumbers.end(); iter++) {
            stdf << *iter;
        }
    }
    stdf << sdr.handlerType   << sdr.handlerID;
    stdf << sdr.cardType      << sdr.cardID;
    stdf << sdr.loadType      << sdr.loadID;
    stdf << sdr.dibType       << sdr.dibID;
    stdf << sdr.cableType     << sdr.cableID;
    stdf << sdr.contactorType << sdr.contactorID;
    stdf << sdr.laserType     << sdr.laserID;
    stdf << sdr.extraType     << sdr.extraID;

    return stdf;
}

ostream& operator<<(ostream& os, SDRRecord& sdr) {
    string sep = "\t";
    os << sep << "Test Head Number: " << (int) sdr.headNumber << endl;
    os << sep << "Site Group Number: " << (int) sdr.siteGroup << endl;
    os << sep << "Site Count: " << (int) sdr.siteCount << endl;

    os << sep << "Site Numbers (Array): [";
    std::vector<U1>::iterator iter;
    for(iter = sdr.siteNumbers.begin(); iter != sdr.siteNumbers.end(); iter++) {
        os << (int) *iter;
    }
    os << "]" << endl;

    os << sep << "Handler Type: " << sdr.handlerType << endl;
    os << sep << "Handler ID: " << sdr.handlerID << endl;
    os << sep << "Probe Card Type: " << sdr.cardType << endl;
    os << sep << "Probe Card ID: " << sdr.cardID << endl;
    os << sep << "Load Board Type: " << sdr.loadType << endl;
    os << sep << "Load Board ID: " << sdr.loadID << endl;
    os << sep << "DIB Board Type: " << sdr.dibType << endl;
    os << sep << "DIB Board ID: " << sdr.dibID << endl;
    os << sep << "Interface Cable Type: " << sdr.cableType << endl;
    os << sep << "Interface Cable ID: " << sdr.cableID << endl;
    os << sep << "Handler Contacter Type: " << sdr.contactorType << endl;
    os << sep << "Handler Contactor ID: " << sdr.contactorID << endl;
    os << sep << "Laser Type: " << sdr.laserType << endl;
    os << sep << "Laser ID: " << sdr.laserID << endl;
    os << sep << "Extra equipment Type: " << sdr.extraType << endl;
    os << sep << "Extra equipment ID: " << sdr.extraID << endl;
    return os;
}

PMRRecord::PMRRecord(void) {
    index = 0;
    channelType = 0;
    channelName = "";
}
U2 PMRRecord::getLength(void) {
    U2 len = 0;
    len += 2 + 2;
    len += 1 + channelName.length;
    len += 1 + physicalName.length;
    len += 1 + logicalName.length;
    len += 1 + 1;

    return len;
}

RecordHeader PMRRecord::getRecordHeader(void) {
    RecordHeader rec( PMR );
    rec.setLength(getLength());
    return rec;
}

STDFStream& operator>>(STDFStream& stdf, PMRRecord& pmr) {
    stdf >> pmr.index >> pmr.channelType;
    stdf >> pmr.channelName >> pmr.physicalName >> pmr.logicalName;
    stdf >> pmr.headNum >> pmr.siteNum;
    return stdf;
}

ostream& operator<<(ostream& os, PMRRecord& pmr) {
    string sep = "\t";
    os << sep << "Index: " << (int) pmr.index << endl;
    os << sep << "Channel Type: " << pmr.channelType << endl;
    os << sep << "Channel Name: " << pmr.channelName << endl;
    os << sep << "Physical Name: " << pmr.physicalName << endl;
    os << sep << "Logical Name: " << pmr.logicalName << endl;
    os << sep << "Head Number: " << (int) pmr.headNum << endl;
    os << sep << "Site Number: " << (int) pmr.siteNum << endl;
    return os;
}

STDFStream& operator<<(STDFStream& stdf, PMRRecord& pmr) {
    RecordHeader rec = pmr.getRecordHeader();
    stdf << rec;
    stdf << pmr.index << pmr.channelType;
    stdf << pmr.channelName << pmr.physicalName << pmr.logicalName;
    stdf << pmr.headNum << pmr.siteNum;
    return stdf;
}

//
//  PGR - Pin Group Record
//

PGRRecord::PGRRecord(void) {
    index      = 0;
    indexCount = 0;
    pmrIndexes.clear();
}
U2 PGRRecord::getLength(void) {
    U2 len = 2 + (1+groupName.length) + 2;
    if(indexCount > 0) len += (indexCount * 2);

    return len;
}

RecordHeader PGRRecord::getRecordHeader(void) {
    RecordHeader rec(PGR);
    rec.setLength(getLength());

    return rec;
}

STDFStream& operator>>(STDFStream& stdf, PGRRecord& pgr) {
    stdf >> pgr.index;
    stdf >> pgr.groupName >> pgr.indexCount;
    for(U2 i = 0; i < pgr.indexCount; i++) {
        U2 num;
        stdf >> num;
        pgr.pmrIndexes.push_back(num);
    }

    return stdf;
}

ostream& operator<<(ostream& os, PGRRecord& pgr) {
    string sep = "\t";
    os << sep << "Index: " << (int) pgr.index << endl;
    os << sep << "Group Name: " << pgr.groupName << endl;

    os << sep << "Index Count: " << pgr.indexCount << endl;
    os << sep << "PMR Indexes: [ ";
    if(pgr.indexCount > 0) {
        std::vector<U2>::iterator iter;
        for(iter = pgr.pmrIndexes.begin(); iter != pgr.pmrIndexes.end(); iter++) {
            os << (int) *iter << " ";
        }
    }
    os << "]" << endl;

    return os;
}

STDFStream& operator<<(STDFStream& stdf, PGRRecord& pgr) {
    RecordHeader rec = pgr.getRecordHeader();
    stdf << rec;
    stdf << pgr.index << pgr.groupName;
    stdf << pgr.indexCount;
    if(pgr.indexCount > 0) {
        std::vector<U2>::iterator iter;
        for(iter = pgr.pmrIndexes.begin(); iter != pgr.pmrIndexes.end(); iter++) {
            stdf << *iter;
        }
    }
    return stdf;
}

PIRRecord::PIRRecord(void) {
    headNumber = siteNumber = 0;
}

U2 PIRRecord::getLength(void) {
    U2 len = 2;
    return len;
}

STDFStream& operator>>(STDFStream& stdf, PIRRecord& pir) {
    stdf >> pir.headNumber >> pir.siteNumber;
    return stdf;
}
STDFStream& operator<<(STDFStream& stdf, PIRRecord& pir) {
    RecordHeader rec(PIR);
    rec.setLength(pir.getLength());
    stdf << rec;
    stdf << pir.headNumber << pir.siteNumber;
    return stdf;
}
ostream& operator<<(ostream& os, PIRRecord& pir) {
    string sep = "\t";
    os << sep << "Head Number: " << (int) pir.headNumber << endl;
    os << sep << "Site Number: " << (int) pir.siteNumber << endl;
    return os;
}

FTRRecord::FTRRecord(void) {
    testNumber = 0;
    headNumber = siteNumber = 0;
    testFlag = optFlag = 0;
    cycleCount = relVecAdd = repeatCount = numFail = 0;
    xFailAdd = yFailAdd = 0;
    vectorOffset = 0;
    rtnCount = pgmCount = 0;
    patGNumber = 255;
}

U2 FTRRecord::getLength(void) {
    U2 len = 0;
        U4 testNumber;
        U1 headNumber,   siteNumber;
        B1 testFlag,     optFlag;
        U4 cycleCount,   relVecAdd,  repeatCount, numFail;
        I4 xFailAdd,     yFailAdd;
        I2 vectorOffset;
        U2 rtnCount,     pgmCount;
        std::vector<U2> rtnIndexes;
        std::vector<N1> rtnStates;
        std::vector<U2> pgmIndexes;
        std::vector<N1> pgmStates;
        DN failPin;
        CN vectorName, timeSet, opCode, testText;
        CN alarmID, progText, resultText;
        //-----------------------------------------
        U1 patGNumber;
        DN spinMap;

    return len;
}

