
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

#include "STDF.h"
#include "STDFStream.h"

using namespace std;

int main(int argc, char** argv) {

    STDFStream istdf, ostdf;
    RecordHeader rec;

    string filename;
    if(argc > 1)
        filename = argv[1];

    istdf.attach( filename,    STDFStream::ReadOnly);
    ostdf.attach( "temp.stdf", STDFStream::WriteOnly);

    istdf >> rec;
    rec.setLength(2); // For FAR length is always 2

    FARRecord far;
    istdf >> far;
    
    if(far.getCpuType() == 0) {
        cerr << "ERROR: Sorry DEC PDP-11 and VAX processors not supported." << endl;
        exit(1);
    }
    else if(far.getCpuType() == 1) {
        istdf.setByteOrder(BigEndian);
    }
    else if(far.getCpuType() == 2) {
        istdf.setByteOrder(LittleEndian);
    }
    ostdf << far;

    cout << rec << endl;
    cout << far << endl;

    while(istdf.getStatus() == STDFStream::OK) {
        istdf >> rec;
        cout << rec << endl;
        string type = rec.getRecordType();
        if(type == "MIR") {
            MIRRecord mir;
            istdf >> mir;
            cout  << mir;
            ostdf << mir;
        }
        else if(type == "ATR") {
            ATRRecord atr;
            istdf >> atr;
            cout  << atr;
            ostdf << atr;
        }
        else if(type == "SDR") {
            SDRRecord sdr;
            istdf >> sdr;
            cout  << sdr;
            ostdf << sdr;
        }
        else if(type == "PMR") {
            PMRRecord pmr;
            istdf >> pmr;
            cout  << pmr;
            ostdf << pmr;
        }
        else if(type == "PGR") {
            PGRRecord pgr;
            istdf >> pgr;
            cout  << pgr;
            ostdf << pgr;
        }
        else if(type == "PIR") {
            PIRRecord pir;
            istdf >> pir;
            cout  << pir;
            ostdf << pir;
        }
        else {
            cout << "\tTODO" << endl;
            istdf.skip(rec.getLength());
        }
    }

    if(istdf.getStatus() == STDFStream::ReadFail) {
        cerr << "ERROR: Read fail for file." << endl;
    }

    return 1;
}


