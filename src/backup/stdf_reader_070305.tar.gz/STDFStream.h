

#ifndef _STDFSTREAM_H_
#define _STDFSTREAM_H_

#include <iostream>
#include <fstream>
#include <string>
#include "defines.h"
#include "globals.h"
#include "STDF.h"

using namespace std;

string getRecordType(U1 type, U1 subtype);

class STDFStream {
    public:
        enum RWMode { None, ReadOnly, WriteOnly = 2 };
        enum Status { OK, ReadEOF, ReadFail, WriteFail };
//        STDFStream();
        STDFStream(string STDFFileName = "", RWMode mode = None);
        ~STDFStream(); // Destructor

        ByteOrder getByteOrder(void) { return byteOrder; }
        void setByteOrder(ByteOrder order);
        void attach(string STDFFileName, RWMode );
        void setStatus(Status stat);
        void skip(U2 len);

        STDFStream &operator>>(U1 &i);
        STDFStream &operator>>(U2 &i);
        STDFStream &operator>>(U4 &i);
        STDFStream &operator>>(R4 &i);
        STDFStream &operator>>(R8 &i);
        STDFStream &operator>>(C1 &i);
        STDFStream &operator>>(CN &i);
        STDFStream &operator>>(DN &i);

        STDFStream &operator<<(U1 i);
        STDFStream &operator<<(U2 i);
        STDFStream &operator<<(U4 i);
        STDFStream &operator<<(R4 i);
        STDFStream &operator<<(R8 i);
        STDFStream &operator<<(C1 i);
        STDFStream &operator<<(CN i);
        STDFStream &operator<<(DN i);

//        STDFStream &operator>>(RecordHeader     &i);
       
        Status getStatus(void) { return status; }
    protected:
        void setMode(RWMode mode);

    private:
        ByteOrder byteOrder;
        ByteOrder nativeByteOrder;
        bool      noswap;
        RWMode    rwMode;
        ifstream  input;
        ofstream  output;
        string    filename;
        Status status;

};


#endif


