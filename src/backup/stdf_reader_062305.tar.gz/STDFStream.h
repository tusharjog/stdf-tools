

#ifndef _STDFSTREAM_H_
#define _STDFSTREAM_H_

#include <iostream>
#include <string>
#include "defines.h"
#include "STDF.h"

using namespace std;

string getRecordType(U1 type, U1 subtype);

class STDFStream {
    public:
        enum RWMode { None, ReadOnly, WriteOnly };
        enum Status { OK, ReadEOF, ReadFail };
        STDFStream();
        STDFStream(string STDFFileName, RWMode mode);
        ~STDFStream(); // Destructor

        unsigned char getByteOrder(void) { return byteOrder; }
        void setByteOrder(ByteOrder order);
        void attach(string STDFFileName, RWMode );
        void setStatus(Status stat);
        Status getStatus(void) { return status; }
        void skip(U2 len);

        STDFStream &operator>>(U1  &i);
        STDFStream &operator>>(U2 &i);
        STDFStream &operator>>(U4 &i);
        STDFStream &operator>>(R4     &i);
        STDFStream &operator>>(R8     &i);

        STDFStream &operator>>(RecordHeader     &i);

    private:
        ByteOrder byteOrder;
        ByteOrder nativeByteOrder;
        bool      noswap;
        bool      rwMode;
        ifstream  input;
        ofstream  output;
        string    filename;
        Status status;

};


#endif


