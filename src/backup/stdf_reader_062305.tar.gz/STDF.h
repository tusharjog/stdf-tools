
#ifndef _STDF_H_
#define _STDF_H_

#include "defines.h"

class RecordHeader {
    private:
    protected:
        U2 length;
        U1  type;
        U1  subType;
    public:
        RecordHeader(U1 t = 0, U1 st = 0, U2 l = 0);
        void setLength(U2 l);
        void setType(U1 t);
        void setSubType(U1 st);
        void set(U1 t, U1 st, U2 l);
};

#endif

