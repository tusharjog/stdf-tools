
#include "STDF.h"

RecordHeader::RecordHeader(U1 t, U1 st, U2 l) {
    length  = l;
    type    = t;
    subType = st;
}

void RecordHeader::set(U1 t, U1 st, U2 l) {
    type = t;
    subType = st;
    length = l;
}

void RecordHeader::setLength(U2 l) {
    length = l;
}

void RecordHeader::setType(U1 t) {
    type = t;
}

void RecordHeader::setSubType(U1 st) {
    subType = st;
}


