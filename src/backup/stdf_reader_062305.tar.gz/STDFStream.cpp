
#include <string>
#include <fstream>
#include "STDFStream.h"

ByteOrder getNativeByteOrder( void );

STDFStream::STDFStream() {
    rwMode          = None;
    nativeByteOrder = getNativeByteOrder();
    noswap          = true;
    status          = OK;
}

STDFStream::STDFStream(string STDFFileName, RWMode mode) {
    nativeByteOrder = getNativeByteOrder();
    rwMode          = mode;
    filename        = STDFFileName;
    noswap          = true;
    status          = OK;
}

STDFStream::~STDFStream() {
    // Close all io streams here
        if(input.is_open())  input.close();
        if(output.is_open()) output.close();
}

void STDFStream::setByteOrder(ByteOrder order) {
    byteOrder = order;
    if(nativeByteOrder == byteOrder)
        noswap = true;
    else 
        noswap = false;
}

void STDFStream::attach(string STDFFileName, RWMode mode) {
    rwMode = mode;
    filename = STDFFileName;

    if(rwMode == ReadOnly) {
        input.open( STDFFileName.c_str(), ios::in | ios::binary);
        if(! input.is_open()) {
            cerr << "ERROR: Could not open STDF file " << STDFFileName << endl;
            rwMode = None;
            STDFFileName = "";
        }

    }
    else if(rwMode == WriteOnly) {
    }
}

void STDFStream::setStatus(Status stat) {
    if(status == OK)
        status = stat;

}

void STDFStream::skip(U2 len) {
//    char buf[256*256];
//    if(input.readsome( buf, len) != len) {
//        setStatus(ReadEOF);
//    }

//    assert(getStatus() == OK);

    if((getStatus() == OK) && (len != 0)) {
        input.ignore( len);
        if(input.eof()) 
            setStatus(ReadEOF);
        if(input.fail()) 
            setStatus(ReadFail);
    }

    return;
}

STDFStream &STDFStream::operator>>(U1 &i) {
    if(rwMode != ReadOnly) return *this;

    i = 0;
//    assert(getStatus() == OK);

    if(getStatus() == OK) {
        char c;
        c = input.get();
        i = c;
    }

    return *this;
}
STDFStream &STDFStream::operator>>(U2 &i) {
    if(rwMode != ReadOnly) return *this;

    i = 0;
//    assert(getStatus() == OK);
    if(getStatus() == OK) {
        if(noswap) {
            input.read((char *)&i, 2);
            if(!input.good()) {
                i = 0;
                setStatus(ReadEOF);
            }
        }
        else {
            register uchar *p = (uchar *)(&i);
            char buf[2];
            if((input.read(buf, 2)).good()) {
                *p++ = buf[1];
                *p   = buf[0];
            }
            else {
                i = 0;
                setStatus(ReadEOF); 
            }
        }
    }
    return *this;
}
STDFStream &STDFStream::operator>>(U4 &i) {
    if(rwMode != ReadOnly) return *this;

    i = 0;
//    assert(getStatus() == OK);
    if(getStatus() == OK) {

        if(noswap) {
            input.read((char *)&i, 4);
            if(!input.good()) {
                i = 0;
                setStatus(ReadEOF);
            }
        }
        else {
            register uchar *p = (uchar *)(&i);
            char buf[4];
            if((input.read(buf, 4)).good()) {
                *p++ = buf[3];
                *p++ = buf[2];
                *p++ = buf[1];
                *p   = buf[0];
            }
            else  setStatus(ReadEOF); 
        }
    }
    return *this;
}

STDFStream &STDFStream::operator>>(R4 &i) {
    if(rwMode != ReadOnly) return *this;

    i = 0.0;
    //    assert(getStatus() == OK);

    if(getStatus() == OK) {
        if(noswap) {
            input.read((char *)&i, 4);
            if(!input.good()) {
                i = 0.0;
                setStatus(ReadEOF);
            }
        }
        else {
            register uchar *p = (uchar *)(&i);
            char buf[4];
            if((input.read(buf, 4)).good()) {
                *p++ = buf[3];
                *p++ = buf[2];
                *p++ = buf[1];
                *p   = buf[0];
            }
            else  setStatus(ReadEOF); 
        }
    }
    return *this;
}

STDFStream &STDFStream::operator>>(R8 &i) {
    if(rwMode != ReadOnly) return *this;

    i = 0.0;
//    assert(getStatus() == OK);
    if(getStatus() == OK) {

        if(noswap) {
            input.read((char *)&i, 8);
            if(!input.good()) {
                i = 0.0;
                setStatus(ReadEOF);
            }
        }
        else {
            register uchar *p = (uchar *)(&i);
            char buf[8];
            if((input.read(buf, 8)).good()) {
                *p++ = buf[7];
                *p++ = buf[6];
                *p++ = buf[5];
                *p++ = buf[4];
                *p++ = buf[3];
                *p++ = buf[2];
                *p++ = buf[1];
                *p   = buf[0];
            }
            else  setStatus(ReadEOF); 
        }
    }
    return *this;
}

STDFStream &STDFStream::operator>>(RecordHeader &i) {
    if(rwMode != ReadOnly) return *this;

    if(getStatus() == OK) {
        U2 len = 0; U1 t = 0; U1 st = 0;
        *this >> len >> t >> st;
        i.set(t, st, len);
    }

    return *this;
}

ByteOrder getNativeByteOrder( void ) {
    ByteOrder endianness;
    endianness = NotDefined;
    // Check endian-ness during runtime
    unsigned int endianInt;
    endianInt = 0x04030201;
    char* pUINT = (char *) &endianInt;
    if(pUINT[0] == 0x04) { 
//        endianness = BIG_ENDIAN; 
        endianness = BigEndian;
    }
    else if(pUINT[0] == 0x01) { 
//        endianness = LITTLE_ENDIAN;
        endianness = LittleEndian;
    }
    else if(pUINT[0] == 0x03) { 
//        endianness = PDP_ENDIAN;
        endianness = PDPEndian;
    }

    return endianness;
}


string getRecordType(U1 type, U1 subtype) {
    string s;

    if(type == 0) {
        switch(subtype) {
            case 10 : s = "FAR"; break;
            case 20 : s = "ATR"; break;
            default: s = "<>";
        }
    }
    else if(type == 1) {
        switch(subtype) {
            case 10 : s = "MIR"; break;
            case 20 : s = "MRR"; break;
            case 30 : s = "PCR"; break;
            case 40 : s = "HBR"; break;
            case 50 : s = "SBR"; break;
            case 60 : s = "PMR"; break;
            case 62 : s = "PGR"; break;
            case 63 : s = "PLR"; break;
            case 70 : s = "RDR"; break;
            case 80 : s = "SDR"; break;
            default: s = "<>";
        }
    }
    else if(type == 2) {
        switch(subtype) {
            case 10 : s = "WIR"; break;
            case 20 : s = "WRR"; break;
            case 30 : s = "WCR"; break;
            default: s = "<>";
        }
    }
    else if(type == 5) {
        switch(subtype) {
            case 10 : s = "PIR"; break;
            case 20 : s = "PRR"; break;
            default: s = "<>";
        }
    }
    else if(type == 10) {
        switch(subtype) {
            case 30 : s = "TSR"; break;
            default: s = "<>";
        }
    }
    else if(type == 15) {
        switch(subtype) {
            case 10 : s = "PTR"; break;
            case 15 : s = "MPR"; break;
            case 20 : s = "FTR"; break;
            default: s = "<>";
        }
    }
    else if(type == 20) {
        switch(subtype) {
            case 10 : s = "BPS"; break;
            case 20 : s = "EPS"; break;
            default: s = "<>";
        }
    }
    else if(type == 50) {
        switch(subtype) {
            case 10 : s = "GDR"; break;
            case 30 : s = "DTR"; break;
            default: s = "<>";
        }
    }
    else if(type == 180) {
        s = "Reserved for use by Image software";
    }
    else if(type == 181) {
        s = "Reserved for use by IG900 software";
    }
    else {
        s = "<>";
    }
    return s;

}

