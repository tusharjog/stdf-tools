
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

#include "STDFStream.h"

using namespace std;

int main(int argc, char** argv) {

    STDFStream stdf;
    U2 length;
    U1  type;
    U1  subType;
    U1 cpuType, stdfVer;
    RecordHeader rec;

    string filename;
    if(argc > 1)
        filename = argv[1];

    stdf.attach( filename, STDFStream::ReadOnly);

    stdf >> length >> type >> subType;
    length = 2; // For FAR length is always 2
    stdf >> cpuType >> stdfVer;
    if(cpuType == 0) {
        cerr << "ERROR: Sorry DEC PDP-11 and VAX processors not supported." << endl;
        exit(1);
    }
    else if(cpuType == 1) {
        stdf.setByteOrder(BigEndian);
    }
    else if(cpuType == 2) {
        stdf.setByteOrder(LittleEndian);
    }


    stringstream stream;
    cout << (int) length << "\t" << (int) type << "\t" << (int) subType << "\t" << getRecordType( type, subType) << endl;

    stdf >> length >> type >> subType;
    cout << (int) length << "\t" << (int) type << "\t" << (int) subType << "\t" << getRecordType( type, subType) << endl;
    stdf.skip(length);
    while(stdf.getStatus() == STDFStream::OK) {
        stdf >> length >> type >> subType;
        cout << (int) length << "\t" << (int) type << "\t" << (int) subType << "\t" << getRecordType( type, subType) << endl;
        stdf.skip(length);
    }
    if(stdf.getStatus() == STDFStream::ReadFail) {
        cerr << "ERROR: Read fail for file." << endl;
    }

    return 1;
}


