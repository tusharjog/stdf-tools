
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

#include "STDF.h"
#include "STDFStream.h"

using namespace std;

int main(int argc, char** argv) {

    STDFStream istdf, ostdf;
    unsigned long readCount = 0, writeCount = 0;
#ifdef DEBUG
    STDFStream debug;
    debug.attach( "debug.stdf", STDFStream::WriteOnly);
#endif
    RecordHeader rec;

    string filename;
    if(argc > 1)
        filename = argv[1];

    istdf.attach( filename,    STDFStream::ReadOnly);
    ostdf.attach( "temp.stdf", STDFStream::WriteOnly);

    istdf >> rec;
    rec.setLength(2); // For FAR length is always 2

    FARRecord far;
    istdf >> far;
    
    if(far.getCpuType() == 0) {
        cerr << "ERROR: Sorry DEC PDP-11 and VAX processors not supported." << endl;
        exit(1);
    }
    else if(far.getCpuType() == 1) {
        istdf.setByteOrder(BigEndian);
    }
    else if(far.getCpuType() == 2) {
        istdf.setByteOrder(LittleEndian);
    }
    ostdf << far;
#ifdef DEBUG
    debug << far;
#endif

    cout << rec << endl;
    cout << far << endl;

    while(istdf.getStatus() == STDFStream::OK) {
        istdf >> rec;
        readCount = istdf.getByteCount();
        cout << rec << endl;
        string type = rec.getRecordType();
        if(type == "MIR") {
            MIRRecord mir;
            istdf >> mir;
            cout  << mir;
            ostdf << mir;
        }
        else if(type == "ATR") {
            ATRRecord atr;
            istdf >> atr;
            cout  << atr;
            ostdf << atr;
        }
        else if(type == "SDR") {
            SDRRecord sdr;
            istdf >> sdr;
            cout  << sdr;
            ostdf << sdr;
        }
        else if(type == "PMR") {
            PMRRecord pmr;
            istdf >> pmr;
            cout  << pmr;
            ostdf << pmr;
        }
        else if(type == "PGR") {
            PGRRecord pgr;
            istdf >> pgr;
            cout  << pgr;
            ostdf << pgr;
        }
        else if(type == "PIR") {
            PIRRecord pir;
            istdf >> pir;
            cout  << pir;
            ostdf << pir;
        }
        else if(type == "FTR") {
//            U2 len = rec.getLength();
//            char buf[len];
//            istdf.read(buf, len);
            FTRRecord ftr;
            istdf >> ftr;
            cout  << ftr;
#ifdef DEBUG
//            debug << ftr;
#endif
            if(rec.getLength() == ftr.getLength()) {
                ostdf << ftr;
            }
            else if(rec.getLength() > ftr.getLength()) {
                cerr << "ERROR: Reading " << type << ", length mismatch. " 
                    << ftr.getLength() << " vs " << rec.getLength() << endl;
                cerr << "WARNING: Recovering from previous error." << endl;
                istdf.skip(rec.getLength() - ftr.getLength());
            }
            else if(rec.getLength() < ftr.getLength()) {
                cerr << "ERROR: Reading " << type << ", length mismatch. " 
                    << ftr.getLength() << " vs " << rec.getLength() << endl;
                exit(1);
            }
        }
        else if(type == "GDR") {
            GDRRecord gdr;
            istdf >> gdr;
            cout  << gdr;
            ostdf << gdr;
        }
        else if(type == "PTR") {
            PTRRecord ptr;
            istdf >> ptr;
            cout  << ptr;
            ostdf << ptr;
            if(rec.getLength() == ptr.getLength()) {
            }
            else {
                cerr << "ERROR: Reading " << type << ", length mismatch. " 
                    << ptr.getLength() << " vs " << rec.getLength() << endl;
                exit(1);
            }
        }
        else if(type == "PRR") {
            PRRRecord prr;
            istdf >> prr;
            cout  << prr;
            if(rec.getLength() == prr.getLength()) {
                ostdf << prr;
            }
            else if(rec.getLength() > prr.getLength()) {
                cerr << "ERROR: Reading " << type << ", length mismatch. " 
                    << prr.getLength() << " vs " << rec.getLength() << endl;
                cerr << "WARNING: Recovering from previous error." << endl;
                istdf.skip(rec.getLength() - prr.getLength());
            }
            else if(rec.getLength() < prr.getLength()) {
                cerr << "ERROR: Reading " << type << ", length mismatch. " 
                    << prr.getLength() << " vs " << rec.getLength() << endl;
                exit(1);
            }
        }
        else {
            cout << "\tTODO" << endl;
            istdf.skip(rec.getLength());
        }

        writeCount = ostdf.getByteCount();
    }

    if(istdf.getStatus() == STDFStream::ReadFail) {
        cerr << "ERROR: Read fail for file." << endl;
    }

    return 1;
}


